<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="<?=base_url('assets/images/website-logo.png')?>" alt="logo" style="width:70px;">
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <!--<li class="nav-item">
      <a class="nav-link" href="#">Link 1</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Link 2</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Link 3</a>
    </li>-->
  </ul>
</nav>
